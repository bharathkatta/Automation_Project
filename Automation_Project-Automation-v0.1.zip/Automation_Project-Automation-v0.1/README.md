# Automation_Project
The script will perform the following task:
1)It will update the package
2)Check whether apache web server is installed or not; Install in case apache is not found.
3)It will automate the apache start after reboot.
4)It will automatically move the apache log files to s3 bucket after tar operation on it.

conclusion: This script will help to reduce manual effort.
