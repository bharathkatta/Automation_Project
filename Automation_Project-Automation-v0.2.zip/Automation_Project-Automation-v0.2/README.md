######Automation_Project
Task ====Manual task automation script
The script performs the below steps :
1)Script updates the package information
2)Script ensures that the HTTP Apache server is installed
3)Script ensures that HTTP Apache server is running
4)Script ensures that HTTP Apache service is enabled
5)Archiving logs to S3
